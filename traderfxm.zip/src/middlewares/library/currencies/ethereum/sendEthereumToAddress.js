function sendEthereumToAddress() {}

module.exports = sendEthereumToAddress;
