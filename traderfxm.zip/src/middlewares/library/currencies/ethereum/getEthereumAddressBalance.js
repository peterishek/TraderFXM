function readEthereumAddressBalance(address) {
  let balance;
  return balance;
}

module.exports = readEthereumAddressBalance;
